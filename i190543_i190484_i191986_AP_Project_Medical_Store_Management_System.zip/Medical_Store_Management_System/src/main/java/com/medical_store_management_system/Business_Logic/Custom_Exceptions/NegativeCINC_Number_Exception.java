package com.medical_store_management_system.Business_Logic.Custom_Exceptions;

public class NegativeCINC_Number_Exception extends Exception{

    public NegativeCINC_Number_Exception(String msg)
    {
        super(msg);
    }
}
