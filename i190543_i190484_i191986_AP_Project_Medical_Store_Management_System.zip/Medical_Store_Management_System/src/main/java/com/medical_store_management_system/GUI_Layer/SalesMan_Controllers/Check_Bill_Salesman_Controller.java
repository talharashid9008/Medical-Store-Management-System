package com.medical_store_management_system.GUI_Layer.SalesMan_Controllers;

public class Check_Bill_Salesman_Controller {

}
