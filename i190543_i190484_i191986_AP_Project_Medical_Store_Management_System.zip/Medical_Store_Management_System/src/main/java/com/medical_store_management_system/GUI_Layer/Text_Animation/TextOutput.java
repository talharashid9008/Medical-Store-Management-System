package com.medical_store_management_system.GUI_Layer.Text_Animation;

public interface TextOutput {

    void writeText(String text);
}